sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("con.contracts.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map